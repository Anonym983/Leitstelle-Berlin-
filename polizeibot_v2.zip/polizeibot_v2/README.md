# Polizeibot – Landespolizei Berlin

Discord-Bot für Polizei-Roleplay: Personal, Dienstsystem, Fahndungen, Ausweise, Logs und Panels mit Buttons.
Benötigt **Python 3.10+**.

## Ordnerstruktur

| Datei / Ordner | Wofür |
|---|---|
| `config.py` | **Hier änderst du Footer, Farben, Zeiten, Texte der Panels** |
| `main.py` | Startpunkt, lädt alle Module |
| `cogs/` | Jede Funktion ein eigenes Modul (`personal.py`, `dienst.py`, `fahndung.py`, `ausweis.py`, `anwalt.py` …) |
| `core/` | Speicher (`db.py`), Hilfsfunktionen (`helpers.py`), Ausweis-Bild (`ausweis_bild.py`) |
| `cogs/hilfe.py` | Liste der Befehle für `/hilfe` |

## Häufige Änderungen (direkt auf GitHub per Stift-Symbol)

- **Footer** (steht unter jedem Embed): `FOOTER` in `config.py`
- **Texte der Panels**: `TEXTE` in `config.py`
- **Cooldowns, Standard-Laufzeiten**: oben in `config.py`
- **Neue Gefahrenstufe**: `STUFEN` in `config.py`
- **Neuer Befehl**: in das passende Modul in `cogs/` schreiben und in `cogs/hilfe.py` eintragen

## Start

1. Im Developer Portal die Intents **Server Members** und **Message Content** aktivieren.
2. Umgebungsvariablen setzen: `DISCORD_TOKEN` (und optional `GUILD_ID`). Lokal: `.env` aus `.env.example` anlegen.
3. `pip install -r requirements.txt`
4. `python main.py`
5. Bot-Rolle in der Rollenliste **über** alle Dienstgrad-Rollen ziehen.

## Einrichtung in Discord

1. `/setup status` zeigt, was fehlt.
2. `/setup rolle` (Direktion, Polizei, Pflichtverteidiger, Ausweis-Team, Im-Dienst) und `/setup kanal`.
3. `/setup rang_hinzufuegen` für die Teamliste, `/setup logkanal` für Team-Logs.
4. Panels senden: `/panel ausweis`, `/panel anwalt`, `/panel dienst`, `/panel platzverweis`, `/panel fahndung`, `/panel teamliste`.

**Bürger brauchen keine Slash-Rechte:** Ausweis beantragen/vorzeigen und Anwalt rufen laufen über Buttons.
Panels, die mit einer älteren Version gesendet wurden, bitte neu senden.

## Wichtig

- `data.json` enthält alle Daten und gehört **nicht** auf GitHub (steht in `.gitignore`). Beim Hosting muss sie dauerhaft gespeichert werden.
- Den Token niemals in den Code schreiben oder hochladen.
