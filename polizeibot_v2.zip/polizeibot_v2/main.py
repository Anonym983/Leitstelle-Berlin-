"""Startpunkt: python main.py"""
import os
import traceback

import discord
from discord import app_commands
from discord.ext import commands

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")  # optional: Befehle sofort auf deinem Server

# Jede Funktion des Bots ist ein eigenes Modul in cogs/
EXTENSIONS = [
    "cogs.setup_cmds", "cogs.personal", "cogs.dienst", "cogs.teamliste", "cogs.aktivitaet",
    "cogs.fahndung", "cogs.platzverweis", "cogs.anwalt", "cogs.ausweis", "cogs.logs",
    "cogs.hilfe", "cogs.panels",
]


class Tree(app_commands.CommandTree):
    async def interaction_check(self, i: discord.Interaction) -> bool:
        if not i.guild:
            raise app_commands.CheckFailure("❌ Nur auf einem Server nutzbar.")
        return True

    async def on_error(self, i: discord.Interaction, error):
        if isinstance(error, app_commands.CheckFailure):
            msg = str(error)
        else:
            msg = "❌ Es ist ein Fehler aufgetreten."
            traceback.print_exception(type(error), error, error.__traceback__)
        if i.response.is_done():
            await i.followup.send(msg, ephemeral=True)
        else:
            await i.response.send_message(msg, ephemeral=True)


intents = discord.Intents.default()
intents.members = True          # im Developer Portal aktivieren!
intents.message_content = True  # im Developer Portal aktivieren!


class PolizeiBot(commands.Bot):
    async def setup_hook(self):
        for ext in EXTENSIONS:
            await self.load_extension(ext)
        if GUILD_ID:
            g = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=g)
            await self.tree.sync(guild=g)
        else:
            await self.tree.sync()

    async def on_ready(self):
        print(f"Eingeloggt als {self.user}")


bot = PolizeiBot(command_prefix="!", intents=intents, tree_cls=Tree)

if __name__ == "__main__":
    bot.run(TOKEN)
