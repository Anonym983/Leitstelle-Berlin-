"""Hilfsfunktionen, die alle Module nutzen."""
import datetime as dt

import discord
from discord import app_commands

import config
from core.db import db, cfg


def now():
    return dt.datetime.now(dt.timezone.utc)


def future(days):
    return now() + dt.timedelta(days=days)


def ts(d):
    return discord.utils.format_dt(d, "F")


def active(iso):
    return bool(iso) and dt.datetime.fromisoformat(iso) > now()


def bewerbung_gesperrt(user_id):
    """Für deine Bewerbungsseite: ist der Nutzer gesperrt?"""
    return active(db["bewerbungssperren"].get(str(user_id)))


def fmt_dauer(sek):
    h, r = divmod(int(sek), 3600)
    return f"{h} Std {r // 60} Min"


def embed(title, desc, color=None, panel=False):
    """Einheitliches Embed. Footer, Logo, Banner und Farbe kommen aus config.py bzw. /setup."""
    if color is None:
        color = cfg("farbe") or config.BLAU
    e = discord.Embed(title=title, description=desc, color=color, timestamp=now())
    e.set_footer(text=config.FOOTER)
    if cfg("logo"):
        e.set_thumbnail(url=cfg("logo"))
    if panel and cfg("banner"):
        e.set_image(url=cfg("banner"))
    return e


def person(m):
    lpn = db["lpn"].get(str(m.id))
    return f"{m.mention} [LPN{lpn}]" if lpn else m.mention


def has_any(member, *keys):
    if member.guild_permissions.administrator:
        return True
    ids = {cfg(k) for k in keys if cfg(k)}
    return any(r.id in ids for r in member.roles)


def only(*keys):
    """Slash-Befehl nur für Admins oder Inhaber der Rollen (Schlüssel wie 'rl_direktion')."""
    async def pred(i: discord.Interaction):
        if has_any(i.user, *keys):
            return True
        raise app_commands.CheckFailure("❌ Dafür fehlt dir die Berechtigung.")
    return app_commands.check(pred)


async def change_roles(member, add=(), remove=()):
    try:
        add = [r for r in add if r]
        remove = [r for r in remove if r]
        if add:
            await member.add_roles(*add, reason="Polizeibot")
        if remove:
            await member.remove_roles(*remove, reason="Polizeibot")
        return True
    except discord.Forbidden:
        return False


async def mirror(guild, ereignis, emb, skip_id=None):
    """Kopiert ein Ereignis zusätzlich in die zugeordnete Team-Log-Kategorie."""
    k = db["logkanaele"].get(db["auto_log"].get(ereignis, ""))
    ch = guild.get_channel(k["channel"]) if k else None
    if ch and ch.id != skip_id:
        await ch.send(embed=emb)


async def send_log(i, key, emb):
    """Embed in den Log-Kanal (key z.B. 'ch_personal') senden und Bestätigung geben."""
    if not i.response.is_done():
        await i.response.defer(ephemeral=True)
    ch = i.guild.get_channel(cfg(key) or 0) or i.channel
    await ch.send(embed=emb)
    await mirror(i.guild, key[3:], emb, ch.id)
    if key == "ch_personal":
        i.client.dispatch("personal_log", i.guild)  # Teamliste aktualisiert sich
    await i.followup.send("✅ Eintrag erstellt.", ephemeral=True)


async def kat_autocomplete(i: discord.Interaction, current: str):
    return [app_commands.Choice(name=n, value=n) for n in db["logkanaele"]
            if current.lower() in n.lower()][:25]
