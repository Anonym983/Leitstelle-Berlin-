"""Zeichnet die Personalausweis-Karte als Bild."""
import io
import random

import aiohttp
from PIL import Image, ImageDraw, ImageFont


def font(size):
    for p in ("fonts/font.ttf", "DejaVuSans-Bold.ttf", "arialbd.ttf"):
        try:
            return ImageFont.truetype(p, size)
        except OSError:
            pass
    return ImageFont.load_default(size)


def render_card(a, user_id, avatar_bytes):
    W, H = 1000, 600
    img = Image.new("RGBA", (W, H))
    d = ImageDraw.Draw(img)
    for x in range(W):
        t = x / W
        d.line([(x, 0), (x, H)], fill=(int(228 - 40 * t), int(206 - 25 * t), 250, 255))
    d.text((50, 35), "Personalausweis", font=font(46), fill=(15, 15, 15))
    d.text((W - 50, 25), "Berlin", font=font(60), fill=(110, 50, 220), anchor="ra")
    d.line([(50, 115), (W - 50, 115)], fill=(90, 40, 190), width=5)
    zeilen = [f"Name: {a['name']}", f"Geburtsdatum: {a['geb']}",
              f"Führerscheine: {a['fuehrerscheine']}",
              f"Großer Waffenschein: {'Ja' if a['gross'] else 'Nein'}",
              f"Kleiner Waffenschein: {'Ja' if a['klein'] else 'Nein'}"]
    y = 150
    for z in zeilen:
        d.text((55, y), z, font=font(30), fill=(10, 10, 10))
        y += 58
    rnd = random.Random(int(user_id))
    x = 55
    while x < 600:
        w = rnd.choice((3, 4, 6, 8))
        d.rectangle((x, 460, x + w, 565), fill=(0, 0, 0))
        x += w + rnd.choice((3, 4, 6))
    box = (690, 160, 940, 410)
    try:
        av = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA").resize((250, 250))
        img.paste(av, box[:2], av)
    except Exception:
        d.rectangle(box, fill=(60, 60, 60))
    d.text((815, 430), f"Roblox: @{a['roblox']}", font=font(26), fill=(10, 10, 10), anchor="ma")
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, W, H), radius=40, fill=255)
    img.putalpha(mask)
    buf = io.BytesIO()
    img.save(buf, "PNG")
    buf.seek(0)
    return buf


async def roblox_headshot(username):
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post("https://users.roblox.com/v1/usernames/users",
                              json={"usernames": [username], "excludeBannedUsers": False}) as r:
                uid = (await r.json())["data"][0]["id"]
            async with s.get("https://thumbnails.roblox.com/v1/users/avatar-headshot",
                             params={"userIds": uid, "size": "150x150", "format": "Png"}) as r:
                url = (await r.json())["data"][0]["imageUrl"]
            async with s.get(url) as r:
                return await r.read()
    except Exception:
        return None
