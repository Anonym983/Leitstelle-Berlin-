"""Speicher: alles liegt in data.json (nicht auf GitHub hochladen!)."""
import copy
import json
import os

DB_FILE = os.getenv("DB_FILE", "data.json")

DEFAULT_DB = {
    "config": {}, "lpn": {}, "sperren": {}, "disziplin": [], "bewerbungssperren": {},
    "aktivitaet": {}, "dab_warns": {}, "ausweise": {}, "ausweis_anfragen": {}, "anwalt_cd": {},
    "fahndungen": {}, "logkanaele": {}, "auto_log": {},
    "dienst": {"aktiv": {}, "gesamt": {}, "panel": None},
}


def _load():
    data = {}
    if os.path.exists(DB_FILE):
        with open(DB_FILE, encoding="utf-8") as f:
            data = json.load(f)
    for k, v in DEFAULT_DB.items():
        data.setdefault(k, copy.deepcopy(v))
    return data


db = _load()


def save():
    with open(DB_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=1)


def cfg(key):
    return db["config"].get(key)
