"""Fahndungen: Panel mit Buttons, Formular und Slash-Befehle."""
import discord
from discord import app_commands
from discord.ext import commands

import config
from core.db import db, save, cfg
from core.helpers import embed, person, only, has_any, mirror


async def fahndung_ausschreiben(guild, fallback, autor, gesuchte, grund, stufe, beschreibung, zuletzt):
    label, farbe = config.STUFEN[stufe]
    desc = (f"Nach folgender Person wird gefahndet:\n\n• **Person:** {gesuchte}\n"
            f"• **Grund:** {grund}\n• **Gefahrenstufe:** {label}\n• **Beschreibung:** {beschreibung}\n"
            f"• **Zuletzt gesehen:** {zuletzt}\n• **Status:** 🔎 Aktiv\n\n"
            f"*Ausgeschrieben von:* {person(autor)}")
    e = embed("🚨 Fahndung", desc, farbe)
    ch = guild.get_channel(cfg("ch_fahndung") or 0) or fallback
    m = await ch.send(embed=e, view=FahndungView())
    db["fahndungen"][str(m.id)] = {"guild": guild.id, "channel": ch.id, "person": gesuchte,
                                   "aktiv": True, "von": autor.id}
    save()
    await mirror(guild, "fahndung", e, ch.id)


def fahndungen_text(guild_id):
    zeilen = [f"• {f['person']} – https://discord.com/channels/{f['guild']}/{f['channel']}/{mid}"
              for mid, f in db["fahndungen"].items() if f["aktiv"] and f["guild"] == guild_id]
    return "\n".join(zeilen)[:1900] or "Keine aktiven Fahndungen."


class FahndungModal(discord.ui.Modal, title="Fahndung ausschreiben"):
    gesuchte = discord.ui.TextInput(label="Gesuchte Person", max_length=60)
    grund = discord.ui.TextInput(label="Grund", style=discord.TextStyle.paragraph, max_length=400)
    stufe = discord.ui.TextInput(label="Gefahrenstufe (niedrig / mittel / hoch)", default="mittel", max_length=10)
    beschreibung = discord.ui.TextInput(label="Beschreibung / Fahrzeug", required=False, max_length=300)
    zuletzt = discord.ui.TextInput(label="Zuletzt gesehen", required=False, max_length=100)

    async def on_submit(self, i: discord.Interaction):
        stufe = self.stufe.value.strip().lower()
        if stufe not in config.STUFEN:
            return await i.response.send_message("❌ Gefahrenstufe: niedrig, mittel oder hoch.", ephemeral=True)
        await i.response.defer(ephemeral=True)
        await fahndung_ausschreiben(i.guild, i.channel, i.user, self.gesuchte.value, self.grund.value, stufe,
                                    self.beschreibung.value or "Keine Angabe", self.zuletzt.value or "Unbekannt")
        await i.followup.send("✅ Fahndung ausgeschrieben.", ephemeral=True)


class FahndungPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Fahndung ausschreiben", emoji="🚨", style=discord.ButtonStyle.danger, custom_id="fahndung:neu")
    async def neu(self, i: discord.Interaction, b: discord.ui.Button):
        if not has_any(i.user, "rl_polizei", "rl_direktion"):
            return await i.response.send_message("❌ Nur für Polizisten.", ephemeral=True)
        await i.response.send_modal(FahndungModal())

    @discord.ui.button(label="Aktive Fahndungen", emoji="📋", style=discord.ButtonStyle.secondary, custom_id="fahndung:liste")
    async def liste(self, i: discord.Interaction, b: discord.ui.Button):
        if not has_any(i.user, "rl_polizei", "rl_direktion"):
            return await i.response.send_message("❌ Nur für Polizisten.", ephemeral=True)
        await i.response.send_message(fahndungen_text(i.guild.id), ephemeral=True)


class FahndungView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Fahndung beenden", emoji="✅", style=discord.ButtonStyle.success, custom_id="fahndung:end")
    async def beenden(self, i: discord.Interaction, b: discord.ui.Button):
        if not has_any(i.user, "rl_polizei", "rl_direktion"):
            return await i.response.send_message("❌ Keine Berechtigung.", ephemeral=True)
        f = db["fahndungen"].get(str(i.message.id))
        if not f or not f["aktiv"]:
            return await i.response.send_message("Fahndung nicht mehr aktiv.", ephemeral=True)
        f["aktiv"] = False
        save()
        e = i.message.embeds[0]
        e.title = "✅ Fahndung beendet"
        e.color = config.GRUEN
        e.description = e.description.replace("🔎 Aktiv", f"✅ Beendet durch {i.user.mention}")
        await i.response.edit_message(embed=e, view=None)


class Fahndung(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(FahndungView())
        self.bot.add_view(FahndungPanelView())

    @app_commands.command(description="Fahndung ausschreiben")
    @only("rl_polizei", "rl_direktion")
    @app_commands.choices(gefahr=[app_commands.Choice(name=v[0], value=k) for k, v in config.STUFEN.items()])
    async def fahndung(self, i: discord.Interaction, gesuchte_person: str, grund: str,
                       gefahr: app_commands.Choice[str], beschreibung: str = "Keine Angabe",
                       zuletzt_gesehen: str = "Unbekannt"):
        await i.response.defer(ephemeral=True)
        await fahndung_ausschreiben(i.guild, i.channel, i.user, gesuchte_person, grund, gefahr.value,
                                    beschreibung, zuletzt_gesehen)
        await i.followup.send("✅ Fahndung ausgeschrieben.", ephemeral=True)

    @app_commands.command(description="Aktive Fahndungen anzeigen")
    @only("rl_polizei", "rl_direktion")
    async def fahndungen(self, i: discord.Interaction):
        await i.response.send_message(fahndungen_text(i.guild.id), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Fahndung(bot))
