"""Anwalt rufen: Button ODER das Wort im Kanal (für Bürger ohne Slash-Rechte)."""
import time

import discord
from discord.ext import commands

import config
from core.db import db, save, cfg


async def anwalt_rufen(channel, user):
    rolle = cfg("rl_pflichtverteidiger")
    if not rolle:
        return False, "❌ Der Anwalt-Dienst ist noch nicht eingerichtet."
    rest = int(config.ANWALT_COOLDOWN_MIN * 60 - (time.time() - db["anwalt_cd"].get(str(user.id), 0)))
    if rest > 0:
        return False, f"⏳ Bitte warte noch {rest // 60 + 1} Min."
    db["anwalt_cd"][str(user.id)] = time.time()
    save()
    await channel.send(f"<@&{rolle}> {user.mention} benötigt einen Anwalt!",
                       allowed_mentions=discord.AllowedMentions(roles=True, users=True))
    return True, "✅ Ein Anwalt wurde alarmiert."


class AnwaltView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Anwalt rufen", emoji="👔", style=discord.ButtonStyle.primary, custom_id="anwalt:rufen")
    async def rufen(self, i: discord.Interaction, b: discord.ui.Button):
        ok, text = await anwalt_rufen(i.channel, i.user)
        await i.response.send_message(text, ephemeral=True)


class Anwalt(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(AnwaltView())

    @commands.Cog.listener()
    async def on_message(self, msg: discord.Message):
        if msg.author.bot or not msg.guild:
            return
        if msg.channel.id == cfg("ch_anwalt") and msg.content.strip().lower() == config.ANWALT_WORT:
            ok, text = await anwalt_rufen(msg.channel, msg.author)
            if not ok:
                await msg.reply(text, delete_after=8)


async def setup(bot):
    await bot.add_cog(Anwalt(bot))
