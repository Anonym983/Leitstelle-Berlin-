"""/hilfe und /status."""
import discord
from discord import app_commands
from discord.ext import commands

from core.db import db
from core.helpers import embed, fmt_dauer, now

START = now()

# Neue Befehle hier eintragen, dann erscheinen sie in /hilfe.  🔒 = nur Direktion/Admin
HILFE = {
    "🚀 Erste Schritte": [
        ("/setup status", "Zeigt, was eingerichtet ist und was noch fehlt"),
        ("/setup rolle", "Direktion, Polizei, Pflichtverteidiger, Ausweis-Team, Im-Dienst festlegen"),
        ("/setup kanal", "Personal-, Disziplin-, Bewerbungs-, Ausweis-, Fahndungs- und Dienst-Kanal"),
        ("/setup logkanal", "Eigene Log-Kategorien anlegen (z.B. Leitungsebene, Ausbilder)"),
        ("/setup rang_hinzufuegen", "Dienstgrade für die Teamliste festlegen (höchster zuerst)"),
        ("/setup logo · banner · farbe", "Design der Embeds und Panels anpassen"),
        ("/panel …", "Panels mit Buttons senden (siehe Kategorie Panels)"),
    ],
    "🖱️ Panels (Buttons) 🔒": [
        ("/panel ausweis", "Bürger: Ausweis beantragen und vorzeigen, ganz ohne Slash-Befehle"),
        ("/panel anwalt", "Bürger: Anwalt rufen per Button (oder Wort „Anwalt“)"),
        ("/panel dienst", "Polizei: Dienst antreten, Pause, Beenden, Meine Dienstzeit"),
        ("/panel platzverweis", "Polizei: Platzverweis per Formular"),
        ("/panel fahndung", "Polizei: Fahndung ausschreiben und aktive Fahndungen ansehen"),
        ("/panel teamliste", "Teamliste nach Rängen, aktualisiert sich selbst"),
    ],
    "👮 Personal 🔒": [
        ("/einstellung", "Neueinstellung mit LPN und Dienstgrad"),
        ("/uprank", "Beförderung (prüft Uprank-Sperren)"),
        ("/downrank", "Degradierung"),
        ("/entlassung", "Dienstentlassung, entfernt Polizei-Rolle"),
        ("/disziplinar", "Aktenvermerk mit Aktenzeichen, Ablauf und optionaler Uprank-Sperre"),
        ("/akten", "Aktive Akteneinträge eines Beamten"),
        ("/bewerbungssperre", "Bewerbungssperre verhängen (/bewerbungssperre_aufheben hebt sie auf)"),
        ("/aktivitaetscheck", "Check mit Button; wer nicht bestätigt, bekommt eine DAB-Warnung"),
    ],
    "🚓 Dienst": [
        ("/dienstzeit", "Deine Dienstzeit oder die eines anderen"),
        ("/dienst_topliste", "Top-10 der Dienstzeiten"),
        ("/dienst_zwangsbeenden 🔒", "Hängengebliebenen Dienst beenden"),
    ],
    "🚨 Fahndung": [
        ("/fahndung", "Fahndung ausschreiben (mit Gefahrenstufe)"),
        ("/fahndungen", "Alle aktiven Fahndungen mit Link"),
    ],
    "🪪 Ausweise": [
        ("/ausweis_lizenzen", "Führerscheine und Waffenscheine eintragen (Ausweis-Team)"),
        ("/personalausweis get", "Zeigt einen Ausweis (Bürger nutzen den Button im Panel)"),
    ],
    "📝 Logs": [
        ("/teamlog", "Eintrag in eine Log-Kategorie schreiben"),
        ("/setup auto_log 🔒", "Ereignisse automatisch in eine Kategorie kopieren"),
        ("/status", "Ping, Laufzeit und Zahlen des Bots"),
    ],
}


class HilfeSelect(discord.ui.Select):
    def __init__(self):
        super().__init__(placeholder="Kategorie wählen…", options=[discord.SelectOption(label=k) for k in HILFE])

    async def callback(self, i: discord.Interaction):
        k = self.values[0]
        text = "\n".join(f"`{c}` – {t}" for c, t in HILFE[k])
        await i.response.edit_message(embed=embed(k, text), view=self.view)


class HilfeView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        self.add_item(HilfeSelect())


class Hilfe(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(description="Alle Befehle und Funktionen erklärt")
    async def hilfe(self, i: discord.Interaction):
        desc = ("Wähle unten eine Kategorie aus.\n🔒 = nur Direktion/Admin\n\n"
                "**Neu hier?** Starte mit `/setup status`.")
        await i.response.send_message(embed=embed("📖 Hilfe", desc, panel=True), view=HilfeView(), ephemeral=True)

    @app_commands.command(description="Bot-Status und Zahlen")
    async def status(self, i: discord.Interaction):
        aktiv_f = sum(1 for f in db["fahndungen"].values() if f["aktiv"])
        desc = (f"• **Ping:** {round(self.bot.latency * 1000)} ms\n"
                f"• **Laufzeit:** {fmt_dauer((now() - START).total_seconds())}\n"
                f"• **Beamte im Register:** {len(db['lpn'])}\n"
                f"• **Im Dienst:** {len(db['dienst']['aktiv'])}\n"
                f"• **Aktive Fahndungen:** {aktiv_f}\n"
                f"• **Ausweise:** {len(db['ausweise'])}")
        await i.response.send_message(embed=embed("📊 Bot-Status", desc), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Hilfe(bot))
