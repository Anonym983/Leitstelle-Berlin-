"""/panel ... - sendet Panels mit Buttons (nur Direktion)."""
import discord
from discord import app_commands
from discord.ext import commands

import config
from core.db import db, save, cfg
from core.helpers import embed, only
from cogs.anwalt import AnwaltView
from cogs.ausweis import AusweisView
from cogs.dienst import DienstView, dienst_embed
from cogs.fahndung import FahndungPanelView
from cogs.platzverweis import PlatzverweisView
from cogs.teamliste import teamliste_embed


class Panels(commands.GroupCog, name="panel", description="Panels mit Buttons senden"):
    def __init__(self, bot):
        self.bot = bot
        super().__init__()

    @app_commands.command(description="Ausweis-Panel für Bürger (Beantragen + Vorzeigen per Button)")
    @only("rl_direktion")
    async def ausweis(self, i: discord.Interaction):
        titel, text = config.TEXTE["ausweis"]
        await i.channel.send(embed=embed(titel, text, panel=True), view=AusweisView())
        await i.response.send_message("✅ Gesendet.", ephemeral=True)

    @app_commands.command(description="Anwalt-Panel für Bürger (dieser Kanal wird Anwalt-Kanal)")
    @only("rl_direktion")
    async def anwalt(self, i: discord.Interaction):
        rolle = cfg("rl_pflichtverteidiger")
        if not rolle:
            return await i.response.send_message("❌ Erst /setup rolle → Pflichtverteidiger.", ephemeral=True)
        db["config"]["ch_anwalt"] = i.channel.id
        save()
        titel, text = config.TEXTE["anwalt"]
        text = text.format(rolle=f"<@&{rolle}>", minuten=config.ANWALT_COOLDOWN_MIN)
        await i.channel.send(embed=embed(titel, text, panel=True), view=AnwaltView())
        await i.response.send_message("✅ Gesendet.", ephemeral=True)

    @app_commands.command(description="Dienstpanel senden")
    @only("rl_direktion")
    async def dienst(self, i: discord.Interaction):
        await i.response.send_message("✅ Gesendet.", ephemeral=True)
        m = await i.channel.send(embed=dienst_embed(i.guild), view=DienstView())
        db["dienst"]["panel"] = {"channel": i.channel.id, "message": m.id}
        save()

    @app_commands.command(description="Platzverweis-Panel senden")
    @only("rl_direktion")
    async def platzverweis(self, i: discord.Interaction):
        titel, text = config.TEXTE["platzverweis"]
        await i.channel.send(embed=embed(titel, text, panel=True), view=PlatzverweisView())
        await i.response.send_message("✅ Gesendet.", ephemeral=True)

    @app_commands.command(description="Fahndungs-Panel senden")
    @only("rl_direktion")
    async def fahndung(self, i: discord.Interaction):
        titel, text = config.TEXTE["fahndung_panel"]
        await i.channel.send(embed=embed(titel, text, panel=True), view=FahndungPanelView())
        await i.response.send_message("✅ Gesendet.", ephemeral=True)

    @app_commands.command(description="Teamliste senden (aktualisiert sich automatisch)")
    @only("rl_direktion")
    async def teamliste(self, i: discord.Interaction):
        if not db["config"].get("raenge"):
            return await i.response.send_message("❌ Erst Ränge festlegen: /setup rang_hinzufuegen", ephemeral=True)
        await i.response.send_message("✅ Teamliste gesendet.", ephemeral=True)
        m = await i.channel.send(embed=teamliste_embed(i.guild))
        db["config"]["teamliste"] = {"channel": i.channel.id, "message": m.id}
        save()


async def setup(bot):
    await bot.add_cog(Panels(bot))
