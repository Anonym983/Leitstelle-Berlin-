"""Aktivitätscheck mit Buttons; wer nicht bestätigt, bekommt automatisch eine DAB-Warnung."""
import datetime as dt

import discord
from discord import app_commands
from discord.ext import commands, tasks

import config
from core.db import db, save, cfg
from core.helpers import embed, only, has_any, ts, now


class AktivitaetView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Aktivität bestätigen", emoji="✅", style=discord.ButtonStyle.success, custom_id="akt:confirm")
    async def confirm(self, i: discord.Interaction, b: discord.ui.Button):
        e = db["aktivitaet"].get(str(i.message.id))
        if not e or e["done"]:
            return await i.response.send_message("Dieser Check ist beendet.", ephemeral=True)
        if cfg("rl_polizei") and not has_any(i.user, "rl_polizei"):
            return await i.response.send_message("Nur für Polizisten.", ephemeral=True)
        if i.user.id not in e["confirmed"]:
            e["confirmed"].append(i.user.id)
            save()
        await i.response.send_message("✅ Aktivität bestätigt.", ephemeral=True)

    @discord.ui.button(label="Wer hat bestätigt?", emoji="📋", style=discord.ButtonStyle.secondary, custom_id="akt:list")
    async def liste(self, i: discord.Interaction, b: discord.ui.Button):
        e = db["aktivitaet"].get(str(i.message.id))
        if not e:
            return await i.response.send_message("Check nicht gefunden.", ephemeral=True)
        ja = [f"<@{u}>" for u in e["confirmed"]]
        rolle = i.guild.get_role(cfg("rl_polizei") or 0)
        nein = [m.mention for m in (rolle.members if rolle else []) if m.id not in e["confirmed"]]
        text = (f"**✅ Bestätigt ({len(ja)}):**\n{', '.join(ja) or '–'}\n\n"
                f"**❌ Offen ({len(nein)}):**\n{', '.join(nein) or '–'}")
        await i.response.send_message(text[:1900], ephemeral=True, allowed_mentions=discord.AllowedMentions.none())


class Aktivitaet(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(AktivitaetView())
        self.fristen.start()

    async def cog_unload(self):
        self.fristen.cancel()

    @tasks.loop(minutes=1)
    async def fristen(self):
        n = now()
        for mid, e in list(db["aktivitaet"].items()):
            if e["done"] or dt.datetime.fromisoformat(e["deadline"]) > n:
                continue
            e["done"] = True
            guild = self.bot.get_guild(e["guild"])
            rolle = guild.get_role(cfg("rl_polizei") or 0) if guild else None
            if not rolle:
                continue
            fehlend = [m for m in rolle.members if not m.bot and m.id not in e["confirmed"]]
            for m in fehlend:
                db["dab_warns"].setdefault(str(m.id), []).append(
                    {"grund": "Aktivitätscheck nicht bestätigt", "datum": n.isoformat()})
            ch = guild.get_channel(cfg("ch_disziplin") or 0) or guild.get_channel(e["channel"])
            if ch:
                txt = ", ".join(m.mention for m in fehlend) or "Niemand 🎉"
                await ch.send(embed=embed("📢 Aktivitätscheck beendet",
                                          f"**DAB-Warnung erhalten ({len(fehlend)}):**\n{txt}"[:4000], config.ROT),
                              allowed_mentions=discord.AllowedMentions.none())
        save()

    @fristen.before_loop
    async def _warten(self):
        await self.bot.wait_until_ready()

    @app_commands.command(description="Aktivitätscheck starten")
    @only("rl_direktion")
    async def aktivitaetscheck(self, i: discord.Interaction, stunden: int = 24):
        rolle = cfg("rl_polizei")
        if not rolle:
            return await i.response.send_message("❌ Erst /setup rolle → Polizei.", ephemeral=True)
        bis = now() + dt.timedelta(hours=stunden)
        titel, text = config.TEXTE["aktivitaet"]
        await i.response.send_message("✅ Check gestartet.", ephemeral=True)
        m = await i.channel.send(f"<@&{rolle}>", embed=embed(titel, text.format(frist=ts(bis)), config.ORANGE),
                                 view=AktivitaetView(), allowed_mentions=discord.AllowedMentions(roles=True))
        db["aktivitaet"][str(m.id)] = {"guild": i.guild.id, "channel": i.channel.id,
                                       "deadline": bis.isoformat(), "confirmed": [], "done": False}
        save()


async def setup(bot):
    await bot.add_cog(Aktivitaet(bot))
