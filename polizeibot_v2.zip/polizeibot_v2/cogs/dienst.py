"""Dienstsystem: Panel mit Buttons (Antreten, Pause, Beenden, Meine Zeit) + Dienstzeit-Befehle."""
import datetime as dt

import discord
from discord import app_commands
from discord.ext import commands, tasks

import config
from core.db import db, save, cfg
from core.helpers import embed, person, only, has_any, change_roles, mirror, fmt_dauer, now


def dienst_sekunden(r):
    n = now()
    gesamt = (n - dt.datetime.fromisoformat(r["start"])).total_seconds() - r.get("pause_total", 0)
    if r.get("pause_start"):
        gesamt -= (n - dt.datetime.fromisoformat(r["pause_start"])).total_seconds()
    return max(0, gesamt)


def gesamt_sekunden(uid):
    sek = db["dienst"]["gesamt"].get(str(uid), 0)
    r = db["dienst"]["aktiv"].get(str(uid))
    return sek + (dienst_sekunden(r) if r else 0)


def dienst_embed(guild):
    zeilen = []
    for uid, r in db["dienst"]["aktiv"].items():
        m = guild.get_member(int(uid))
        name = person(m) if m else f"<@{uid}>"
        status = "⏸️ Pause" if r.get("pause_start") else "🟢 Im Dienst"
        seit = discord.utils.format_dt(dt.datetime.fromisoformat(r["start"]), "R")
        zeilen.append(f"{status} · {name} · seit {seit}")
    liste = "\n".join(zeilen)[:3500] or "Niemand"
    titel, text = config.TEXTE["dienst"]
    return embed(titel, f"{text}\n\n**Aktuell im Dienst ({len(zeilen)}):**\n{liste}", config.GRUEN, panel=True)


async def refresh_dienst_panel(guild):
    p = db["dienst"].get("panel")
    ch = guild.get_channel(p["channel"]) if p else None
    if not ch:
        return
    try:
        msg = await ch.fetch_message(p["message"])
        await msg.edit(embed=dienst_embed(guild))
    except discord.HTTPException:
        pass


async def dienst_beenden(guild, member_id, durch=None):
    r = db["dienst"]["aktiv"].pop(str(member_id), None)
    if not r:
        return None
    sek = dienst_sekunden(r)
    gesamt = db["dienst"]["gesamt"].get(str(member_id), 0) + sek
    db["dienst"]["gesamt"][str(member_id)] = gesamt
    save()
    m = guild.get_member(member_id)
    if m:
        await change_roles(m, remove=[guild.get_role(cfg("rl_imdienst") or 0)])
    await refresh_dienst_panel(guild)
    name = person(m) if m else f"<@{member_id}>"
    extra = f"\n*Beendet durch:* {durch.mention}" if durch else ""
    e = embed("🔴 Dienst beendet",
              f"{name}\n• **Dauer:** {fmt_dauer(sek)}\n• **Gesamt:** {fmt_dauer(gesamt)}{extra}", config.ROT)
    ch = guild.get_channel(cfg("ch_dienst") or 0)
    if ch:
        await ch.send(embed=e)
    await mirror(guild, "dienst", e, ch.id if ch else None)
    return sek


class DienstView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Dienst antreten", emoji="🟢", style=discord.ButtonStyle.success, custom_id="dienst:start")
    async def antreten(self, i: discord.Interaction, b: discord.ui.Button):
        if not has_any(i.user, "rl_polizei", "rl_direktion"):
            return await i.response.send_message("❌ Nur für Polizisten.", ephemeral=True)
        akt = db["dienst"]["aktiv"]
        if str(i.user.id) in akt:
            return await i.response.send_message("Du bist bereits im Dienst.", ephemeral=True)
        akt[str(i.user.id)] = {"start": now().isoformat(), "pause_total": 0, "pause_start": None}
        save()
        await i.response.defer(ephemeral=True)
        await change_roles(i.user, add=[i.guild.get_role(cfg("rl_imdienst") or 0)])
        await refresh_dienst_panel(i.guild)
        await i.followup.send("🟢 Du bist jetzt im Dienst. Viel Erfolg!", ephemeral=True)

    @discord.ui.button(label="Pause", emoji="⏸️", style=discord.ButtonStyle.secondary, custom_id="dienst:pause")
    async def pause(self, i: discord.Interaction, b: discord.ui.Button):
        r = db["dienst"]["aktiv"].get(str(i.user.id))
        if not r:
            return await i.response.send_message("Du bist nicht im Dienst.", ephemeral=True)
        if r.get("pause_start"):
            r["pause_total"] += (now() - dt.datetime.fromisoformat(r["pause_start"])).total_seconds()
            r["pause_start"] = None
            text = "▶️ Pause beendet."
        else:
            r["pause_start"] = now().isoformat()
            text = "⏸️ Pause gestartet. Die Pausenzeit zählt nicht zur Dienstzeit."
        save()
        await i.response.defer(ephemeral=True)
        await refresh_dienst_panel(i.guild)
        await i.followup.send(text, ephemeral=True)

    @discord.ui.button(label="Dienst beenden", emoji="🔴", style=discord.ButtonStyle.danger, custom_id="dienst:end")
    async def beenden(self, i: discord.Interaction, b: discord.ui.Button):
        if str(i.user.id) not in db["dienst"]["aktiv"]:
            return await i.response.send_message("Du bist nicht im Dienst.", ephemeral=True)
        await i.response.defer(ephemeral=True)
        sek = await dienst_beenden(i.guild, i.user.id)
        await i.followup.send(f"🔴 Dienst beendet. Dauer: **{fmt_dauer(sek)}**", ephemeral=True)

    @discord.ui.button(label="Meine Dienstzeit", emoji="⏱️", style=discord.ButtonStyle.secondary, custom_id="dienst:zeit")
    async def zeit(self, i: discord.Interaction, b: discord.ui.Button):
        await i.response.send_message(f"⏱️ Deine Gesamt-Dienstzeit: **{fmt_dauer(gesamt_sekunden(i.user.id))}**",
                                      ephemeral=True)


class Dienst(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(DienstView())
        self.vergessene_dienste.start()

    async def cog_unload(self):
        self.vergessene_dienste.cancel()

    @tasks.loop(minutes=1)
    async def vergessene_dienste(self):
        if not self.bot.guilds:
            return
        n = now()
        for uid, r in list(db["dienst"]["aktiv"].items()):
            if (n - dt.datetime.fromisoformat(r["start"])).total_seconds() > config.DIENST_MAX_STUNDEN * 3600:
                await dienst_beenden(self.bot.guilds[0], int(uid))

    @vergessene_dienste.before_loop
    async def _warten(self):
        await self.bot.wait_until_ready()

    @app_commands.command(description="Dienstzeit anzeigen")
    async def dienstzeit(self, i: discord.Interaction, user: discord.Member | None = None):
        z = user or i.user
        aktiv = str(z.id) in db["dienst"]["aktiv"]
        desc = f"{person(z)}\n• **Gesamt:** {fmt_dauer(gesamt_sekunden(z.id))}" + ("\n• 🟢 Aktuell im Dienst" if aktiv else "")
        await i.response.send_message(embed=embed("⏱️ Dienstzeit", desc), ephemeral=True)

    @app_commands.command(description="Top-10 der Dienstzeiten")
    @only("rl_polizei", "rl_direktion")
    async def dienst_topliste(self, i: discord.Interaction):
        top = sorted(db["dienst"]["gesamt"].items(), key=lambda kv: kv[1], reverse=True)[:10]
        zeilen = [f"**{n}.** <@{uid}> – {fmt_dauer(s)}" for n, (uid, s) in enumerate(top, 1)]
        await i.response.send_message(embed=embed("🏆 Top Dienstzeiten", "\n".join(zeilen) or "Noch keine Daten.", config.ORANGE),
                                      allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(description="Dienst eines Beamten zwangsweise beenden")
    @only("rl_direktion")
    async def dienst_zwangsbeenden(self, i: discord.Interaction, user: discord.Member):
        await i.response.defer(ephemeral=True)
        sek = await dienst_beenden(i.guild, user.id, i.user)
        await i.followup.send("✅ Dienst beendet." if sek is not None else "Der Beamte ist nicht im Dienst.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Dienst(bot))
