"""/setup ... - Bot einrichten (nur Administratoren)."""
import discord
from discord import app_commands
from discord.ext import commands

import config
from core.db import db, save, cfg
from core.helpers import embed, kat_autocomplete


class SetupCog(commands.GroupCog, name="setup", description="Bot einrichten (nur Administratoren)"):
    def __init__(self, bot):
        self.bot = bot
        super().__init__()

    async def interaction_check(self, i: discord.Interaction) -> bool:
        if i.user.guild_permissions.administrator:
            return True
        raise app_commands.CheckFailure("❌ Nur Administratoren dürfen den Bot einrichten.")

    @app_commands.command(name="status", description="Zeigt, was schon eingerichtet ist und was noch fehlt")
    async def status(self, i: discord.Interaction):
        g = i.guild

        def kanal(k):
            ch = g.get_channel(cfg("ch_" + k) or 0)
            return ch.mention if ch else "❌ fehlt"

        def rolle(k):
            r = g.get_role(cfg("rl_" + k) or 0)
            return r.mention if r else "❌ fehlt"

        e = embed("⚙️ Einrichtungs-Status", "Hier siehst du, was schon eingerichtet ist.")
        e.add_field(name="Kanäle", value="\n".join(f"{v}: {kanal(k)}" for k, v in config.KANAELE.items()), inline=False)
        e.add_field(name="Rollen", value="\n".join(f"{v}: {rolle(k)}" for k, v in config.ROLLEN.items()), inline=False)
        logk = "\n".join(f"**{n}** → <#{v['channel']}>" for n, v in db["logkanaele"].items()) or "–"
        e.add_field(name="Team-Log-Kategorien", value=logk[:1000], inline=False)
        raenge = [g.get_role(r) for r in db["config"].get("raenge", [])]
        e.add_field(name="Ränge (Teamliste)", value=" › ".join(r.mention for r in raenge if r) or "❌ keine", inline=False)
        farbe = "#%06X" % (cfg("farbe") or config.BLAU)
        e.add_field(name="Design",
                    value=f"Logo: {'✅' if cfg('logo') else '–'} · Banner: {'✅' if cfg('banner') else '–'} · Farbe: {farbe}",
                    inline=False)
        pruefen = raenge + [g.get_role(cfg("rl_polizei") or 0), g.get_role(cfg("rl_imdienst") or 0)]
        zu_hoch = [r for r in pruefen if r and r >= g.me.top_role]
        if zu_hoch:
            e.add_field(name="⚠️ Rollen-Reihenfolge",
                        value="Die Bot-Rolle muss in den Servereinstellungen **über** diesen Rollen stehen:\n"
                              + " ".join(r.mention for r in zu_hoch), inline=False)
        await i.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name="kanal", description="Kanal für eine Funktion festlegen")
    @app_commands.choices(typ=[app_commands.Choice(name=v, value=k) for k, v in config.KANAELE.items()])
    async def kanal(self, i: discord.Interaction, typ: app_commands.Choice[str], kanal: discord.TextChannel):
        db["config"]["ch_" + typ.value] = kanal.id
        save()
        await i.response.send_message(f"✅ {typ.name}: {kanal.mention}", ephemeral=True)

    @app_commands.command(name="rolle", description="Rolle für eine Funktion festlegen")
    @app_commands.choices(typ=[app_commands.Choice(name=v, value=k) for k, v in config.ROLLEN.items()])
    async def rolle(self, i: discord.Interaction, typ: app_commands.Choice[str], rolle: discord.Role):
        db["config"]["rl_" + typ.value] = rolle.id
        save()
        await i.response.send_message(f"✅ {typ.name}: {rolle.mention}", ephemeral=True,
                                      allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="logkanal", description="Team-Log-Kategorie anlegen (z.B. Leitungsebene, Ausbilder)")
    async def logkanal(self, i: discord.Interaction, name: str, kanal: discord.TextChannel,
                       rolle: discord.Role | None = None):
        db["logkanaele"][name.strip()] = {"channel": kanal.id, "rolle": rolle.id if rolle else None}
        save()
        extra = f" – schreiben darf: {rolle.mention}" if rolle else ""
        await i.response.send_message(f"✅ Log-Kategorie **{name}** → {kanal.mention}{extra}", ephemeral=True,
                                      allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="logkanal_entfernen", description="Team-Log-Kategorie löschen")
    @app_commands.autocomplete(name=kat_autocomplete)
    async def logkanal_entfernen(self, i: discord.Interaction, name: str):
        db["logkanaele"].pop(name, None)
        for k in [k for k, v in db["auto_log"].items() if v == name]:
            db["auto_log"].pop(k)
        save()
        await i.response.send_message("✅ Entfernt.", ephemeral=True)

    @app_commands.command(name="auto_log", description="Ereignis automatisch zusätzlich in eine Log-Kategorie kopieren")
    @app_commands.choices(ereignis=[app_commands.Choice(name=v, value=k) for k, v in config.AUTO_EREIGNISSE.items()])
    @app_commands.autocomplete(kategorie=kat_autocomplete)
    async def auto_log(self, i: discord.Interaction, ereignis: app_commands.Choice[str], kategorie: str):
        if kategorie not in db["logkanaele"]:
            return await i.response.send_message("❌ Diese Log-Kategorie gibt es nicht.", ephemeral=True)
        db["auto_log"][ereignis.value] = kategorie
        save()
        await i.response.send_message(f"✅ {ereignis.name} werden zusätzlich in **{kategorie}** kopiert.", ephemeral=True)

    @app_commands.command(name="rang_hinzufuegen", description="Rang für die Teamliste hinzufügen (höchster Rang zuerst)")
    async def rang_hinzufuegen(self, i: discord.Interaction, rolle: discord.Role):
        raenge = db["config"].setdefault("raenge", [])
        if rolle.id not in raenge:
            raenge.append(rolle.id)
        save()
        await i.response.send_message(f"✅ {rolle.mention} ist jetzt Rang Nr. {raenge.index(rolle.id) + 1}.",
                                      ephemeral=True, allowed_mentions=discord.AllowedMentions.none())

    @app_commands.command(name="rang_entfernen", description="Rang aus der Teamliste entfernen (ohne Angabe: alle)")
    async def rang_entfernen(self, i: discord.Interaction, rolle: discord.Role | None = None):
        if rolle:
            db["config"]["raenge"] = [r for r in db["config"].get("raenge", []) if r != rolle.id]
        else:
            db["config"]["raenge"] = []
        save()
        await i.response.send_message("✅ Erledigt.", ephemeral=True)

    @app_commands.command(name="logo", description="Logo (Bild-Link) für alle Embeds setzen")
    async def logo(self, i: discord.Interaction, url: str):
        if not url.startswith("http"):
            return await i.response.send_message("❌ Bitte einen Bild-Link (https://…) angeben.", ephemeral=True)
        db["config"]["logo"] = url
        save()
        await i.response.send_message(embed=embed("✅ Logo gesetzt", "So sehen deine Embeds jetzt aus."), ephemeral=True)

    @app_commands.command(name="banner", description="Banner (Bild-Link) für alle Panels setzen")
    async def banner(self, i: discord.Interaction, url: str):
        if not url.startswith("http"):
            return await i.response.send_message("❌ Bitte einen Bild-Link (https://…) angeben.", ephemeral=True)
        db["config"]["banner"] = url
        save()
        await i.response.send_message(embed=embed("✅ Banner gesetzt", "So sehen deine Panels jetzt aus.", panel=True),
                                      ephemeral=True)

    @app_commands.command(name="farbe", description="Hauptfarbe als HEX-Code setzen, z.B. 2B5BFF")
    async def farbe(self, i: discord.Interaction, hexwert: str):
        try:
            wert = int(hexwert.strip().lstrip("#"), 16)
            assert 0 <= wert <= 0xFFFFFF
        except (ValueError, AssertionError):
            return await i.response.send_message("❌ Bitte einen HEX-Code wie 2B5BFF angeben.", ephemeral=True)
        db["config"]["farbe"] = wert
        save()
        await i.response.send_message(embed=embed("✅ Farbe gesetzt", "So sieht die neue Hauptfarbe aus."), ephemeral=True)


async def setup(bot):
    await bot.add_cog(SetupCog(bot))
