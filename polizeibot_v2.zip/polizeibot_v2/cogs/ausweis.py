"""Ausweissystem: Antrag per Button, Prüfung durch das Team, Ausweis per Button vorzeigen."""
import asyncio
import datetime as dt
import time

import discord
from discord import app_commands
from discord.ext import commands

import config
from core.ausweis_bild import render_card, roblox_headshot
from core.db import db, save, cfg
from core.helpers import embed, only, has_any


class AusweisModal(discord.ui.Modal, title="Personalausweis"):
    rp_name = discord.ui.TextInput(label="Vor- und Nachname (IC)", max_length=40)
    geb = discord.ui.TextInput(label="Geburtsdatum (TT.MM.JJJJ)", max_length=10)
    roblox = discord.ui.TextInput(label="Roblox-Username", max_length=30)

    async def on_submit(self, i: discord.Interaction):
        try:
            dt.datetime.strptime(self.geb.value.strip(), "%d.%m.%Y")
        except ValueError:
            return await i.response.send_message("❌ Datum bitte als TT.MM.JJJJ.", ephemeral=True)
        ch = i.guild.get_channel(cfg("ch_ausweis_pruefung") or 0)
        if not ch:
            return await i.response.send_message("❌ Der Prüf-Kanal ist noch nicht eingerichtet.", ephemeral=True)
        daten = {"user": i.user.id, "name": self.rp_name.value.strip(),
                 "geb": self.geb.value.strip(), "roblox": self.roblox.value.strip().lstrip("@")}
        desc = (f"**Antragsteller:** {i.user.mention}\n**Name:** {daten['name']}\n"
                f"**Geburtsdatum:** {daten['geb']}\n**Roblox:** @{daten['roblox']}")
        m = await ch.send(embed=embed("🪪 Ausweisantrag", desc), view=AusweisReviewView())
        db["ausweis_anfragen"][str(m.id)] = daten
        save()
        await i.response.send_message("✅ Dein Antrag wurde eingereicht. Du bekommst eine Nachricht, sobald er geprüft ist.",
                                      ephemeral=True)


class AusweisReviewView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def _handle(self, i: discord.Interaction, ok: bool):
        if not has_any(i.user, "rl_ausweis_team", "rl_direktion"):
            return await i.response.send_message("❌ Keine Berechtigung.", ephemeral=True)
        req = db["ausweis_anfragen"].pop(str(i.message.id), None)
        if not req:
            return await i.response.send_message("❌ Antrag nicht mehr vorhanden.", ephemeral=True)
        if ok:
            alt = db["ausweise"].get(str(req["user"]), {})
            db["ausweise"][str(req["user"])] = {
                "name": req["name"], "geb": req["geb"], "roblox": req["roblox"],
                "fuehrerscheine": alt.get("fuehrerscheine", "Keine"),
                "gross": alt.get("gross", False), "klein": alt.get("klein", False)}
        save()
        e = i.message.embeds[0]
        e.color = config.GRUEN if ok else config.ROT
        e.add_field(name="Status", value=f"{'✅ Angenommen' if ok else '❌ Abgelehnt'} von {i.user.mention}")
        await i.response.edit_message(embed=e, view=None)
        member = i.guild.get_member(req["user"])
        if member:
            try:
                await member.send("✅ Dein Ausweis wurde ausgestellt! Zeige ihn mit dem Button „Ausweis vorzeigen“."
                                  if ok else "❌ Dein Ausweisantrag wurde abgelehnt.")
            except discord.HTTPException:
                pass

    @discord.ui.button(label="Annehmen", style=discord.ButtonStyle.success, custom_id="ausweis:ok")
    async def ok(self, i: discord.Interaction, b: discord.ui.Button):
        await self._handle(i, True)

    @discord.ui.button(label="Ablehnen", style=discord.ButtonStyle.danger, custom_id="ausweis:no")
    async def no(self, i: discord.Interaction, b: discord.ui.Button):
        await self._handle(i, False)


async def ausweis_zeigen(i: discord.Interaction, ziel):
    a = db["ausweise"].get(str(ziel.id))
    if not a:
        return await i.response.send_message("❌ Es gibt noch keinen Ausweis. Beantrage ihn mit dem Button „Ausweis beantragen“.",
                                             ephemeral=True)
    await i.response.defer()
    avatar = await roblox_headshot(a["roblox"])
    buf = await asyncio.to_thread(render_card, a, ziel.id, avatar)
    await i.followup.send(content=f"🪪 Ausweis von {ziel.mention}", file=discord.File(buf, "personalausweis.png"),
                          allowed_mentions=discord.AllowedMentions.none())


class AusweisView(discord.ui.View):
    """Panel-Buttons für Bürger - keine Slash-Rechte nötig."""
    _cooldown = {}

    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Ausweis beantragen", emoji="🪪", style=discord.ButtonStyle.primary, custom_id="ausweis:beantragen")
    async def beantragen(self, i: discord.Interaction, b: discord.ui.Button):
        await i.response.send_modal(AusweisModal())

    @discord.ui.button(label="Ausweis vorzeigen", emoji="📇", style=discord.ButtonStyle.success, custom_id="ausweis:zeigen")
    async def zeigen(self, i: discord.Interaction, b: discord.ui.Button):
        rest = config.AUSWEIS_COOLDOWN_SEK - (time.time() - self._cooldown.get(i.user.id, 0))
        if rest > 0:
            return await i.response.send_message(f"⏳ Bitte warte noch {int(rest) + 1} Sekunden.", ephemeral=True)
        self._cooldown[i.user.id] = time.time()
        await ausweis_zeigen(i, i.user)


class Ausweis(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(AusweisView())
        self.bot.add_view(AusweisReviewView())

    @app_commands.command(description="Führerscheine & Waffenscheine eines Ausweises setzen")
    @only("rl_ausweis_team", "rl_direktion")
    async def ausweis_lizenzen(self, i: discord.Interaction, user: discord.Member, fuehrerscheine: str,
                               grosser_waffenschein: bool = False, kleiner_waffenschein: bool = False):
        a = db["ausweise"].get(str(user.id))
        if not a:
            return await i.response.send_message("❌ Der Nutzer hat keinen Ausweis.", ephemeral=True)
        a.update({"fuehrerscheine": fuehrerscheine, "gross": grosser_waffenschein, "klein": kleiner_waffenschein})
        save()
        await i.response.send_message("✅ Aktualisiert.", ephemeral=True)

    personalausweis = app_commands.Group(name="personalausweis", description="Personalausweis")

    @personalausweis.command(name="get", description="Personalausweis anzeigen")
    async def get(self, i: discord.Interaction, user: discord.Member | None = None):
        await ausweis_zeigen(i, user or i.user)


async def setup(bot):
    await bot.add_cog(Ausweis(bot))
