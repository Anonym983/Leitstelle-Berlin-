"""Platzverweis per Button + Formular (kein Slash-Befehl nötig)."""
import discord
from discord.ext import commands

import config
from core.helpers import embed, person, has_any


class PlatzverweisModal(discord.ui.Modal, title="Platzverweis eintragen"):
    person_ = discord.ui.TextInput(label="Person (Roblox-Name)", max_length=40)
    ort = discord.ui.TextInput(label="Ort", max_length=80)
    grund = discord.ui.TextInput(label="Grund", style=discord.TextStyle.paragraph, max_length=500)
    dauer = discord.ui.TextInput(label="Dauer", default=config.PLATZVERWEIS_DAUER_STANDARD, max_length=40)

    async def on_submit(self, i: discord.Interaction):
        desc = (f"• **Person:** {self.person_.value}\n• **Ort:** {self.ort.value}\n"
                f"• **Grund:** {self.grund.value}\n• **Dauer:** {self.dauer.value}\n\n"
                f"*Ausgestellt von:* {person(i.user)}")
        await i.channel.send(embed=embed("🚧 Platzverweis", desc, config.ORANGE))
        await i.response.send_message("✅ Platzverweis veröffentlicht.", ephemeral=True)


class PlatzverweisView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Platzverweis eintragen", emoji="🚧", style=discord.ButtonStyle.primary,
                       custom_id="platzverweis:open")
    async def open(self, i: discord.Interaction, b: discord.ui.Button):
        if not has_any(i.user, "rl_polizei", "rl_direktion"):
            return await i.response.send_message("❌ Nur für Polizisten.", ephemeral=True)
        await i.response.send_modal(PlatzverweisModal())


class Platzverweis(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(PlatzverweisView())


async def setup(bot):
    await bot.add_cog(Platzverweis(bot))
