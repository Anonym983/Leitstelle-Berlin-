"""Team-Logs: Einträge in eigene Kategorien (Leitungsebene, Ausbilder, ...)."""
import discord
from discord import app_commands
from discord.ext import commands

from core.db import db
from core.helpers import embed, person, has_any, kat_autocomplete


class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(description="Eintrag in einen Team-Log schreiben (z.B. Leitungsebene, Ausbilder)")
    @app_commands.autocomplete(kategorie=kat_autocomplete)
    async def teamlog(self, i: discord.Interaction, kategorie: str, titel: str, text: str):
        k = db["logkanaele"].get(kategorie)
        ch = i.guild.get_channel(k["channel"]) if k else None
        if not ch:
            return await i.response.send_message("❌ Unbekannte Log-Kategorie.", ephemeral=True)
        if k["rolle"]:
            erlaubt = i.user.guild_permissions.administrator or any(r.id == k["rolle"] for r in i.user.roles)
        else:
            erlaubt = has_any(i.user, "rl_polizei", "rl_direktion")
        if not erlaubt:
            return await i.response.send_message("❌ Dafür fehlt dir die Berechtigung.", ephemeral=True)
        desc = f"{text}\n\n• **Kategorie:** {kategorie}\n\n*Eingetragen von:* {person(i.user)}"
        await ch.send(embed=embed(f"📝 {titel}", desc))
        await i.response.send_message("✅ Log eingetragen.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Logs(bot))
