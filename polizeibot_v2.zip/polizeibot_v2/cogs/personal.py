"""Personal-Befehle (nur Direktion): Einstellung, Uprank, Downrank, Entlassung, Disziplinar, Bewerbungssperre."""
import random
import string

import discord
from discord import app_commands
from discord.ext import commands, tasks

import config
from core.db import db, save
from core.helpers import embed, person, only, change_roles, send_log, future, ts, active, now
import datetime as dt


class Personal(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.aufraeumen.start()

    async def cog_unload(self):
        self.aufraeumen.cancel()

    @tasks.loop(hours=1)
    async def aufraeumen(self):
        db["disziplin"] = [d for d in db["disziplin"] if active(d["bis"])]
        save()

    @app_commands.command(description="Neueinstellung eintragen")
    @only("rl_direktion")
    async def einstellung(self, i: discord.Interaction, user: discord.Member, lpn: int,
                          dienstgrad: discord.Role, notiz: str):
        await i.response.defer(ephemeral=True)
        db["lpn"][str(user.id)] = lpn
        save()
        await change_roles(user, add=[dienstgrad, i.guild.get_role(db["config"].get("rl_polizei") or 0)])
        desc = (f"Wir begrüßen unseren neuen Kollegen!\nDer Anwärter {user.mention} [LPN{lpn}] "
                f"wurde offiziell in den Polizeidienst aufgenommen.\n\n"
                f"• **Zugeteilter Dienstgrad:** {dienstgrad.mention}\n• **Einstellungsnotiz:** {notiz}\n\n"
                f"*Gezeichnet von der Direktion:* {person(i.user)}")
        await send_log(i, "ch_personal", embed("💫 Neueinstellung", desc))

    @app_commands.command(description="Beförderung eintragen")
    @only("rl_direktion")
    async def uprank(self, i: discord.Interaction, user: discord.Member, dienstgrad: discord.Role,
                     begruendung: str, alter_dienstgrad: discord.Role | None = None):
        sperre = db["sperren"].get(str(user.id))
        if active(sperre):
            bis = dt.datetime.fromisoformat(sperre)
            return await i.response.send_message(f"❌ Uprank-Sperre bis {ts(bis)}.", ephemeral=True)
        await i.response.defer(ephemeral=True)
        await change_roles(user, add=[dienstgrad], remove=[alter_dienstgrad])
        desc = (f"Dem Beamten {person(user)} wurde mit sofortiger Wirkung ein neuer Dienstgrad verliehen.\n\n"
                f"• **Neuer Dienstgrad:** {dienstgrad.mention}\n• **Begründung:** {begruendung}\n\n"
                f"*Gezeichnet von der Direktion:* {person(i.user)}")
        await send_log(i, "ch_personal", embed("🔼 Beförderung", desc, config.GRUEN))

    @app_commands.command(description="Degradierung eintragen")
    @only("rl_direktion")
    async def downrank(self, i: discord.Interaction, user: discord.Member, dienstgrad: discord.Role,
                       begruendung: str, alter_dienstgrad: discord.Role | None = None):
        await i.response.defer(ephemeral=True)
        await change_roles(user, add=[dienstgrad], remove=[alter_dienstgrad])
        desc = (f"Der Beamte {person(user)} wurde mit sofortiger Wirkung degradiert. "
                f"Der Vorfall wurde aktenkundig gemacht.\n\n"
                f"• **Neuer Dienstgrad:** {dienstgrad.mention}\n• **Begründung:** {begruendung}\n\n"
                f"*Gezeichnet von der Direktion:* {person(i.user)}")
        await send_log(i, "ch_personal", embed("🔽 Degradierung", desc, config.ORANGE))

    @app_commands.command(description="Dienstentlassung eintragen")
    @only("rl_direktion")
    async def entlassung(self, i: discord.Interaction, user: discord.Member, grund: str,
                         dienstgrad: discord.Role | None = None):
        await i.response.defer(ephemeral=True)
        desc = (f"Der Beamte {person(user)} wurde mit sofortiger Wirkung vom Dienst freigestellt "
                f"und aus dem Polizeiregister entfernt.\n\n• **Entlassungsgrund:** {grund}\n\n"
                f"*Gezeichnet von der Direktion:* {person(i.user)}")
        await change_roles(user, remove=[dienstgrad, i.guild.get_role(db["config"].get("rl_polizei") or 0)])
        db["lpn"].pop(str(user.id), None)
        save()
        await send_log(i, "ch_personal", embed("❌ Dienstentlassung", desc, config.ROT))

    @app_commands.command(description="Disziplinarmaßnahme einleiten")
    @only("rl_direktion")
    async def disziplinar(self, i: discord.Interaction, user: discord.Member, vergehen: str,
                          laufzeit_tage: int = config.LAUFZEIT_TAGE_STANDARD, uprank_sperre_tage: int = 0):
        await i.response.defer(ephemeral=True)
        az = "".join(random.choices(string.ascii_uppercase + string.digits, k=config.AKTENZEICHEN_LAENGE))
        bis = future(laufzeit_tage)
        db["disziplin"].append({"id": az, "user": user.id, "vergehen": vergehen, "bis": bis.isoformat()})
        text = vergehen
        if uprank_sperre_tage > 0:
            db["sperren"][str(user.id)] = future(uprank_sperre_tage).isoformat()
            text += f" + {uprank_sperre_tage} Tage Uprank-Sperre"
        save()
        desc = (f"Gegen den Beamten {person(user)} wurde ein offizieller Aktenvermerk erstellt.\n\n"
                f"• **Dienstvergehen:** {text}\n• **Aktenzeichen (ID):** `{az}`\n"
                f"• **Läuft automatisch ab:** {ts(bis)}\n\n*Gezeichnet von:* {person(i.user)}")
        await send_log(i, "ch_disziplin", embed("Disziplinarmaßnahme eingeleitet", desc, config.ROT))

    @app_commands.command(description="Aktive Akteneinträge eines Beamten anzeigen")
    @only("rl_direktion")
    async def akten(self, i: discord.Interaction, user: discord.Member):
        eintraege = [d for d in db["disziplin"] if d["user"] == user.id and active(d["bis"])]
        if not eintraege:
            return await i.response.send_message("Keine aktiven Einträge.", ephemeral=True)
        zeilen = [f"`{d['id']}` – {d['vergehen']} (bis {ts(dt.datetime.fromisoformat(d['bis']))})" for d in eintraege]
        await i.response.send_message("\n".join(zeilen)[:1900], ephemeral=True)

    @app_commands.command(description="Bewerbungssperre verhängen")
    @only("rl_direktion")
    async def bewerbungssperre(self, i: discord.Interaction, user: discord.User, grund: str,
                               tage: int = config.BEWERBUNGSSPERRE_TAGE_STANDARD):
        await i.response.defer(ephemeral=True)
        bis = future(tage)
        db["bewerbungssperren"][str(user.id)] = bis.isoformat()
        save()
        desc = (f"Gegen {user.mention} wurde eine Bewerbungsperre verhängt. Bewerbungen des Nutzers "
                f"werden für die angegebene Dauer nicht berücksichtigt.\n\n• **Grund:** {grund}\n"
                f"• **Dauer:** {tage}d (Bis: {ts(bis)})")
        await send_log(i, "ch_bewerbung", embed("⛔ Bewerbungsperre", desc, config.ROT))

    @app_commands.command(description="Bewerbungssperre aufheben")
    @only("rl_direktion")
    async def bewerbungssperre_aufheben(self, i: discord.Interaction, user: discord.User):
        db["bewerbungssperren"].pop(str(user.id), None)
        save()
        await i.response.send_message("✅ Sperre aufgehoben.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Personal(bot))
