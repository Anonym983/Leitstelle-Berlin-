"""Teamliste nach Rängen, aktualisiert sich selbst."""
import discord
from discord.ext import commands, tasks

import config
from core.db import db
from core.helpers import embed, person


def teamliste_embed(guild):
    raenge = [guild.get_role(r) for r in db["config"].get("raenge", [])]
    gesehen, total = set(), 0
    e = embed("📋 Teamliste", "", panel=True)
    for r in (x for x in raenge if x):
        mem = [m for m in r.members if not m.bot and m.id not in gesehen]
        if not mem:
            continue
        gesehen.update(m.id for m in mem)
        total += len(mem)
        mem.sort(key=lambda m: db["lpn"].get(str(m.id), 9999))
        e.add_field(name=f"{r.name} ({len(mem)})", value="\n".join(person(m) for m in mem)[:1020], inline=False)
    e.description = f"**{total}** Beamte im Dienstregister"
    return e


async def refresh_teamliste(guild):
    p = db["config"].get("teamliste")
    ch = guild.get_channel(p["channel"]) if p else None
    if not ch:
        return
    try:
        msg = await ch.fetch_message(p["message"])
        await msg.edit(embed=teamliste_embed(guild))
    except discord.HTTPException:
        pass


class Teamliste(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.update.start()

    async def cog_unload(self):
        self.update.cancel()

    @tasks.loop(minutes=config.TEAMLISTE_INTERVALL_MIN)
    async def update(self):
        for g in self.bot.guilds:
            await refresh_teamliste(g)

    @update.before_loop
    async def _warten(self):
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_personal_log(self, guild):
        await refresh_teamliste(guild)


async def setup(bot):
    await bot.add_cog(Teamliste(bot))
